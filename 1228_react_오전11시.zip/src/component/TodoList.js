// 검색기능도 입력하는 검색어를 처리할 state변수를 만듭니다
import {useState} from "react";
import TodoItem from "./TodoItem";
import "./TodoList.css";


const TodoList = ({todo}) => {
    const [search, setSearch] = useState("");
    const onChangeSearch = (e) => {
        setSearch(e.target.value);
    }
 
    return <div className="TodoList">
        <h4>Todo List 👑</h4>
        <input value = {search} onChange={onChangeSearch} 
        className="SearchBar" placeholder="검색어를 입력하세요" />
        <div className="list_wrapper">
            {/* map메서드의 콜백함수가 html이 아닌 
            준비된 TodoItem 컴포넌트를 화면에 렌더링(출력)
            하도록 코드를 수정하였습니다
            todo에는 할일 아이템이 객체데이터로 저장되어 있으므로
            스프레드 연산자 기능을 활용하여 개별 데이터로 
            분리하여 props로 전달 후, 화면에 렌더링 하도록 하였습니다 */}
            {todo.map((it) => (
                // 리스트 각 컴포넌트에 key로 할일 아이템의 id를 전달
                <TodoItem key={it.id} {...it} />
            ))}
        </div>
        </div>
} 

export default TodoList;