import "./Editor.css";
import { useState } from "react";
import { getFormattedDate } from "../util";

const Editor = ({ initData, onSubmit }) => {
  const [state, setState] = useState({
    date: getFormattedDate(new Date()),
    emotionId: 3,
    content: "",
  });
  // 날짜관련 이벤트 핸들러 만들기
  // 사용자가 입력된 날짜를 변경하면 함수가 호출되어
  // state를 업데이트 합니다
  const handleChangeDate = (e) => {
    setState({
      ...state,
      date: e.target.value,
    });
  };
  return (
    <div className="Editor">
      <div className="editor_section">
        <h4>오늘의 날짜</h4>
        <div className="input_wrapper">
          <input type="date" value={state.date} onChange={handleChangeDate} />
        </div>
      </div>
      <div className="editor_section">
        {/* 여기에 코드가 들갑니다 */}
        <h4>오늘의 감정</h4>
      </div>
      <div className="editor_section">
        <h4>오늘의 일기</h4>
        <div className="input_wrapper">
          <textarea
            placeholder="오늘은 어땟나요?"
            value={state.content}
            onChange={handleChangeContent}
          />
        </div>
      </div>
      <div className="editor_section">{/* 작성완료, 취소관련 코드 */}</div>
    </div>
  );
};
export default Editor;
