import Button from "../component/Button";
import Header from "../component/Header";
import Editor from "../component/Editor";
const Home = () => {
  return (
    <div>
      <div>
        <Header title={"Home"} 
        leftChild={
            <Button
            type="positive"
            text={"긍정버튼"}
            onClick={() => {
              alert("positive button");
            }}
          />
        }
        rightChild={
            <Button
            type="negative"
            text={"부정버튼"}
            onClick={() => {
              alert("negative button");
            }}
          />
        }
        />
      </div>
      <Editor />
    </div>
    
  );
};
export default Home;
