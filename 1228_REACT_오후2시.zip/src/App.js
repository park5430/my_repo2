// CRUD 기능의 대표적인 구현 방법은 REACT HOOKS 중에 useState입니다
import "./App.css";
import Header from "./component/Header";
import TodoEditor from "./component/TodoEditor";
import TodoList from "./component/TodoList";
import { useReducer, useRef } from "react";
import TestComp from "./component/TestComp";

// 가짜 json형식의 데이터 객체를 형성하여 crud로직을 만들고
// 실제데이터를 갈아끼우는 형태로 개발하시면 됩니다

const mockTodo = [
  {
    id: 0,
    inDone: false,
    content: "react 공부",
    createdDate: new Date().getTime(),
  },
  {
    id: 1,
    inDone: false,
    content: "개발자 되기",
    createdDate: new Date().getTime(),
  },
  {
    id: 2,
    inDone: false,
    content: "자료 다운로드",
    createdDate: new Date().getTime(),
  },
];

function reducer(state, action) {
  switch (action.type) {
    case "CREATE": {
      return [action.newItem, ...state];
    }
    default:
      return state;
  }
}


function App() {
  // useRef의 초기값을 3으로 설정한 이유는
  // 우리가 생성한 가짜데이터 id가 2로 끝나서입니다
  const idRef = useRef(3);
  const [todo, dispatch] = useReducer(reducer, mockTodo);

  const onCreate = (content) => {
    dispatch({
      type: "CREATE",
      newItem: {
        id: idRef.current,
        content,
        isDone: false,
        createdDate: new Date().getTime(),
      }
    });
    idRef.current += 1;
  };

  const onUpdate = (targetId) => {

  };
  const onDelete = (targetId) => {
    
  };
  return (
    <div className="App">
      <TestComp />
      <Header />
      <TodoEditor onCreate={onCreate} />
      {/* 배열 todo를 TodoList 컴포넌트에 
      props로 전달합니다 */}
      <TodoList todo={todo} onUpdate={onUpdate} onDelete={onDelete}/>
    </div>
  );
}

export default App;
