// 검색기능도 입력하는 검색어를 처리할 state변수를 만듭니다
import {useState} from "react";
import TodoItem from "./TodoItem";
import "./TodoList.css";


const TodoList = ({todo, onUpdate, onDelete}) => {
    const [search, setSearch] = useState("");
    const onChangeSearch = (e) => {
        setSearch(e.target.value);
    }
    const getSearchResult = () => {
        // 검색어가 대소문자를 구분하면 검색기능이 약해지니까
        // 검색어 자체를 전부 소문자 처리하고 비교할 단어도 소문자 처리해서
        // 영어 대소문자 구분으로 검색어가 매치되지 못하는 현상을 방지
        return search === "" ? todo 
        : todo.filter((it) => 
        it.content.toLowerCase().includes(search.toLowerCase()));
    }
    return <div className="TodoList">
        <h4>Todo List 👑</h4>
        <input value = {search} onChange={onChangeSearch} 
        className="SearchBar" placeholder="검색어를 입력하세요" />
        <div className="list_wrapper">
            {/* map메서드의 콜백함수가 html이 아닌 
            준비된 TodoItem 컴포넌트를 화면에 렌더링(출력)
            하도록 코드를 수정하였습니다
            todo에는 할일 아이템이 객체데이터로 저장되어 있으므로
            스프레드 연산자 기능을 활용하여 개별 데이터로 
            분리하여 props로 전달 후, 화면에 렌더링 하도록 하였습니다 */}
            {getSearchResult().map((it) => (
                // 리스트 각 컴포넌트에 key로 할일 아이템의 id를 전달
                <TodoItem key={it.id} {...it} 
                onUpdate={onUpdate} onDelete={onDelete}/>
            ))}
        </div>
        </div>
} 

export default TodoList;