????
???

const filePath = path.join(__dirname, '..', 'data', 'restaurants.json');

function getStoredRestaurants() {
  const fileData = ???
  const storedRestaurants = ???

  return storedRestaurants;
}

function storeRestaurants(storableRestaurants) {
  ????
}

module.exports = {
  getStoredRestaurants: ???
  storeRestaurants: ???
};