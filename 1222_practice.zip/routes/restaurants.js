???
const uuid = require('uuid');

const resData = ???('../util/restaurant-data');

???

router.get('/restaurants', ??? {
  ???
  let nextOrder = 'desc';

  if (order !== 'asc' && order !== 'desc') {
    order = 'asc';
  }

  if (order === 'desc') {
    nextOrder = 'asc';
  }

  const storedRestaurants = ???.getStoredRestaurants();

  storedRestaurants.sort(??? {
    if (
      (order === 'asc' && resA.name > resB.name) ||
      (order === 'desc' && resB.name > resA.name)
    ) {
      return 1;
    }
    return -1;
  });

  res.render('restaurants', {
    numberOfRestaurants: ???,
    restaurants: ???,
    nextOrder: ???
  });
});

router.get('/restaurants/:id', function (req, res) {
  const restaurantId = ???;
  const storedRestaurants = ???;

  for (const restaurant of storedRestaurants) {
    if (restaurant.id === ???) {
      return res.render('restaurant-detail', { restaurant: restaurant });
    }
  }

  res.status(404).render('404');
});

router.get('/recommend', ??? {
  ???;
});

router.post('/recommend', ??? {
  ???
  restaurant.id = uuid.v4();
  ???

  ???

  resData.???(restaurants);

  res.redirect('/confirm');
});

router.get('/confirm', ??? {
  ??;
});

module.exports = router;
