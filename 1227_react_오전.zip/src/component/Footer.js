function Footer () {
    return (
        <footer>
            <h2>밑의 푸터 컨텐츠입니다...</h2>
        </footer>
    );
}

export default Footer;