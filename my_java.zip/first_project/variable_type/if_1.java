public class if_1 {
    public static void main(String[] args) {
        int score = 85;

        if (score >= 90) {
            System.out.println(score + "점은 A 등급입니다");
        }

        else {
            System.out.println(score + "점은 B 등급 이하입니다");
        }
    }
}
