package array;
// 자바에서 날짜 데이터 사용하는 법 + 반복문에 적용

// 데이터 중에서 몇가지 한정된 값을 가지는 경우는 enum 타입 (열거타입)이라 합니다.
// 예를 들어, 각 요일을 원소로 갖는 데이터셋은 아래와 같이 선언될 수 있습니다. 
// 이거는 변수 버전 스위치 구문이라고 생각하실 수 있습니다.
public enum enum_1 {
    MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
}
