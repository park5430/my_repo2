package array;
// 배열 변수 선언 방법은
// int[] intArray 혹은
// int intArray[] 두가지방법 모두 가능하다. 그래도 보통은 전자처럼 쓴다
public class array_1 {
    public static void main(String[] args) {
        // 앞선 방식대로 배열변수를 선언하고 값을 부여하였다
        int[] scores;
        scores = new int[] {83, 90, 87};
        // 배열의 총합을 구해보자
        int sum1 = 0;
        for (int i=0; i<3; i++) {
            sum1 += scores[i];
        }
        System.out.println(sum1);
    }
}
