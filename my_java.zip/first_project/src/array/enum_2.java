// 오늘이 무슨 요일인지 알아내고 그 요일에 맞는 조건문 실행
package array;
// 자바에서 달력 라이브러리 호출
import java.util.Calendar;

public class enum_2 {
    public static void main(String[] args) {
        // 사전에 정의된 날짜타입 변수가 담긴 enum_1 파일 호출
        // 열거된 데이터 셋을 날짜 타입 변수처럼 사용
        // 날짜 데이터 변수를 사전선언해 둠으로서 불필요한 날짜 데이터 무시
        enum_1 today = null;

        // 달력 데이터 얻기; 달력 라이브러리의 사용을 보실 수 있습니다.
        Calendar cal = Calendar.getInstance();

        // 오늘의 요일 데이터 얻기 (1~7)
        // 자바는 요일 숫자가 1부터 시작됩니다. 일요일부터 출발하지요.
        int week = cal.get(Calendar.DAY_OF_WEEK);

        // 날짜 데이터가 1 ~7 까지 일요일 ~ 토요일에 연동되는걸 활용해서
        // switch 구문을 써서 각 날짜 변수에 대입한다
        // 예를 들어 week에서 불러들인 값이 1이면 
        // 정의된 today 변수에 enum_1에 지정된 SUNDAY데이터를 집어넣고 스위치종료
        switch(week) {
            case 1: today = enum_1.SUNDAY ; break;
            case 2: today = enum_1.MONDAY ; break;
            case 3: today = enum_1.TUESDAY ; break;
            case 4: today = enum_1.WEDNESDAY ; break;
            case 5: today = enum_1.THURSDAY ; break;
            case 6: today = enum_1.FRIDAY ; break;
            case 7: today = enum_1.SATURDAY ; break;
        }

        if (today == enum_1.SUNDAY) {
            System.out.println(cal);
            System.out.println(today);
            System.out.println("일요일엔 소고기");
        } else {
            System.out.println(cal);
            System.out.println(today);
            System.out.println("행복한 풀스택");
        }
    }
}
