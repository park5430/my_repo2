package array;
// 다차원 배열 예제를 보시죠
public class array_2 {
    public static void main(String[] args) {
        //줄 끝날때 콤마 붙이다가 마지막에 콤마 안붙이는거 같습니다
        int [][] scores = {
            {80, 90, 96},
            {76, 88}
        };
        // 자바는 파이썬 처럼 
        // 복수 배열데이터 구조를 한번에 보이지 않습니다.
        System.out.println(scores.length);
        System.out.println(scores[0].length);
        System.out.println(scores[1].length);
        System.out.println(scores[1][1]);

// 다차원 배열 생성법
// 1. 다차원 배열 요소 개수가 같은 경우.
int[][] scores2 = new int[2][3];
// scores2는 아래처럼 될 것이다
// int [][] scores2 = {
//     {0, 0, 0},
//     {0, 0, 0}
// };
// 2. 다차원 배열 요소 개수가 다른 경우.
// 1차원 배열의 길이를 지정한 후에 후속 배열의 길이를 따로 지정한다
// int[][] scores3 = new int[2][];
// scores3[0] = new int[4];
// scores3[1] = new int[5];
// scores3는 아래처럼 될 것이다
// int [][] scores3 = {
//     {0, 0, 0, 0},
//     {0, 0, 0, 0, 0}
// };

    }
}
