package var_type2;

public class Boolean {
    public static void main(String[] args) {
int x = 10;
boolean result1 = (x ==20);
boolean result2 = (x !=20);
System.out.println(result1);
System.out.println(result2);
    }
}
