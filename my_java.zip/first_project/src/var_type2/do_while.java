package var_type2;

import java.util.Scanner; // 사용자의 입력값을 받기 위해 불러오는 라이브러리 호출

// do-while 문: 먼저 반복문을 실행시키고 나서 계속할지말지를 결정한다.
// 예를 들어, if, while, for는 먼저 반복문을 돌려야 할지 여부에 대해 확인하고
// while (i <= 10) 반복한다면 do 문으로 먼저 반복조건을 돌리고 나서 체크하는 것이다.
public class do_while {
    public static void main(String[] args) {
        System.out.println("메세지를 입력하세요");
        System.out.println("프로그램을 종료 하려면 q를 입력하세요");
        // scanner, 즉 키보드 입력으로부터 값을 읽어들이는 객체생성
        // 사용자의 입력값을 불러온 Scanner 새로운 객체형태로 입력값을 저장함
        Scanner scanner = new Scanner(System.in);
        // 읽어들인 값을 저장할 변수를 선언해 둠
        String inputString;

        do {
            System.out.print(">>>>");
            // 키보드로 부터 입력값을 읽고 선언해 둔 변수에 저장함
            inputString = scanner.nextLine();
            // 받은 입력값을 화면에 출력함
            System.out.println(inputString);
        } 
        // 무지성으로 do 실행시키고 나서 
        // 사용자가 정지조건인 q를 입력했는지 체크한다
        while (
            !inputString.equals("q")
        );
        // while 문에서 조건을 만족시키지 못해 반복문을 빠져나간다면 
        // 프로그램 종료 조건을 완성 시켜야 한다.
        // 빈칸을 출력해서 한줄 띄우고 나서 
        // 유저에게 프로그램의 종료를 표시해 준다
        System.out.println();
        System.out.println("프로그램 종료");
    }
}
