package var_type2;

public class calc1 {
    public static void main(String[] args) {
int x = 1;
int y = 1;
// x를 1증가 시킨 다음에 1+1+10 이래서 12되는겁니다.
int result1 = ++x + 10;
// 1+10 하고 나서 1 증가시킵니다. 
// 그래서 일단 result2를 11로 먼저 만들어버리고 나서 y가 2됩니다.
int result2 = y++ + 10;
int result3 = y;
System.out.println(result1);
System.out.println(result2);
System.out.println(result3);
    }
}
