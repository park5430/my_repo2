package var_type2;
public class if_stmt2 {
    public static void main(String[] args) {
        int score = 85;
        if (score >= 90) {
            System.out.println(score + "점은 A 등급입니다");
        }
        else if (score >= 80) {
            System.out.println(score + "점은 B 등급입니다");
        }
        else {
            System.out.println(score + "점은 C 등급입니다");
        }
    }
}

// char grade = (score >= 90) ? 'A' : ( (score >= 80) ? 'B' : 'C');
//         System.out.println(score + "점은" + grade + "등급입니다");