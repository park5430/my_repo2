package var_type2;
// 1부터 10까지 순차적으로 출력하는 예시입니다.
public class for_1 {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i + " ");
        }
    }
}
