package var_type2;
public class random_num_switch {
    public static void main(String[] args) {
        int num = (int) (Math.random() * 6) +1;
switch(num){
    case 1:
    System.out.println("1 이 출력되었어요");
    break;
    case 2:
    System.out.println("2 이 출력되었어요");
    break;
    case 3:
    System.out.println("3 이 출력되었어요");
    break;
    case 4:
    System.out.println("4 이 출력되었어요");
    break;
    case 5:
    System.out.println("5 이 출력되었어요");
    break;
    default:
    System.out.println("6 이 출력되었어요");
    break;
}

    }
}
