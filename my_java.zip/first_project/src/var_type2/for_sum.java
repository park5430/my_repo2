package var_type2;
// 1부터 100까지의 합을 for문으로 해보세요 ^^
public class for_sum {
    public static void main(String[] args) {
        int sum = 0;
        int i;
        for (i =1; i <=100; i ++) {
            
            sum += i;
        }

        System.out.println(sum);
    }
}
