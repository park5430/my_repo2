package var_type2;

// 변수의 범위 (scope)
public class variable_scope {
    public static void main(String[] args) {
        int v1 = 15;
		if(v1 > 10) {
			int v2 = v1 - 10;
		}
        else {
            // v2 변수의 범위가 다르기 때문에 컴파일 에러가 납니다.
            // int v2 = 15;
            int v3 = v1 + v2 +5;
        }
    }
}
