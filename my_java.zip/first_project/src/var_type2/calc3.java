package var_type2;
// 자바에서 논리연산자를 확인하겠습니다.
// 논리연산자란 and, or 등 조건문을 걸 수 있는 명령문을 의미합니다
// 자바스크립트와 유사합니다 
// and 조건은 && 혹은 & 둘다 됩니다
// or 조건은 | 혹은 || 둘다 됩니다
public class calc3 {
    public static void main(String[] args) {
        // 유니코드를 기준으로 글자에 부여된 숫자를 사용할 수 있어요
        // 예를 들어, 대문자 A는 유니코드숫자 65입니다.
// int charCode = 'A';

// if( (65<=charCode) && (charCode<=90) ) {
//     System.out.println(charCode);
//     System.out.println("대문자이군요.");
// }

// XOR 연산자의 예시 입니다. 하난 맞고 하난 틀려야 참으로 처리되어요
int value = 6;
if ( (value % 2 == 0) ^ (value % 3 == 0)) {
    System.out.println("2혹은 3의 배수 입니다");
}

    }
}
