package var_type2;

public class while_1 {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 10) {
            System.out.println(i + " ");
        }
    }
}
