package var_type2;
// 2중 for문을 이용해서 구구단 한번 만들어 보시죠 ^^
public class googoo_dan {
    public static void main(String[] args) {
        // 1. 밖의 for문으로 몇단인지 만들어 주기
        for (int m =2; m<=9; m++) {
            // 2. 안의 for 문으로 각 단의 구구단 결과 채우기
            for (int i = 1; i<=9; i++) {
                System.out.println(m+" x " + i + "=" + m*i);
            }
        }
    }
}
