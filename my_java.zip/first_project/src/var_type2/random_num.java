package var_type2;
// 1~6 사이 무작위 수가 나오게 하는 코드는 뭘까요?
public class random_num {
    public static void main(String[] args) {
        int num = (int) (Math.random() * 6) +1;
        // 아래처럼 말고 if 절 써서 해보세요~
        System.out.println(num + "이 출력되었어요");
    // 예제: 무작위로 1-6 사이 값이 나왔을 때 "xx이 출력되었어요"
    // if절을 사용해서 해당값이 나왔다고 출력되게 코드 짜보세요

if (num == 1) {
    System.out.println("1 이 출력되었어요");
}
else if (num == 2) {
    System.out.println("2 이 출력되었어요");
}
else if (num == 3) {
    System.out.println("3 이 출력되었어요");
}
else if (num == 4) {
    System.out.println("4 이 출력되었어요");
}
else if (num == 5) {
    System.out.println("5 이 출력되었어요");
}
else {
    System.out.println("6 이 출력되었어요");
}
    }
}
