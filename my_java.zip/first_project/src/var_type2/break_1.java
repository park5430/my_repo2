package var_type2;
// 1에서 6까지 주사위를 계속 굴려서 6이 나오면 종료
public class break_1 {
    public static void main(String[] args) {
        while(true) {
            int num = (int)(Math.random()*6)+1;
            System.out.println(num);
            if(num==6) {
                break;
            }
            System.out.println("프로그램종료");
        }
    }
}