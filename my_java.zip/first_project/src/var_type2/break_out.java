package var_type2;
// 바깥 for문에서 알파벳 대문자를 반복하고
// 내부 for문에서 알파벳 소문자를 반복하는 반복문을 만듭니다.
// 내부 for문의 요소가 특정 조건을 만족하는 경우 
// 외부 반복문을 종료하는 예제입니다.
public class break_out {
    public static void main(String[] args) {
        // 2중 for문을 셋업하고 
        // 외부의 for문에 outer라는 이름을 부여
        // for 문의 원리상, 알파벳에 해당하는 정수를 넘겨서 진행하니
        // 알파벳이 유니코드에 해당하는 정수로 변환되어야 합니다
        // 그래서 작은따옴표이고 char 변수로 선언 되어야합니다
        Outer: for(char upper='A'; upper<='Z'; upper++) {
            for(char lower='a'; lower<='z'; lower++) {
                // 각 for문의 결과를 출력합니다.
                System.out.println(upper + "-" + lower);
                // 특정 조건을 만족하면 외부의 반복문을 끔으로써
                // 프로그램의 종료를 이끌어낼 수 있다.
                if (upper=='C') {
                    break Outer;
                }
            }
        }
        System.out.println("프로그램 종료");
    }
}
