package var_type2;

public class type_conv {
    public static void main(String[] args) {
byte Byteval = 10;
int Int_val = Byteval;
System.out.println(Int_val);

    }
}
