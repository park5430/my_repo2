package memory;

public class char_ex2 {
    public static void main(String[] args) {
        String k_id = "830322-1000000";
        String firstnum = k_id.substring(0,6);
        System.out.println(firstnum);

        String secondnum = k_id.substring(7);
        System.out.println(secondnum);

        String oldstr = "자바 문자열은 변하지 않습니다. 자바 문자열은 String";
        // 데이터의 길이를 셉니다.
        int length1 = oldstr.length();
        // 주어진 문자열 시작 지점을 파악합니다.
        // 문자열이 없으면 -1을 출력합니다.
        int index = oldstr.indexOf("변하지");
        // 주어진 문자열이 있는지 없는지 참거짓으로 찾아줍니다
        boolean index2 = oldstr.contains("변하지");
        // replace내부 함수는 파이썬과 동일
        String newStr = oldstr.replace("자바", "java");
        System.out.println(length1);
        System.out.println(index);
        System.out.println(index2);
        System.out.println(newStr);
    }
}
