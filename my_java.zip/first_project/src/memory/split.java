package memory;
// 문자열을 분리해서 얻고싶은 결과를 받을 수 있습니다
// 콤마로 문자열을 분리해서 배열에 저장하고 싶은 경우
public class split {
    public static void main(String[] args) {
        String board = "1,자바 학습,참조 타입 String을 학습합니다.,홍길동";
        // 배열형태의 변수를 선언하고 
        // 배열의 각 요소는 콤마로 구분하여 저장합니다
        String [] tokens = board.split(",");

        System.out.println(tokens[0]);
        System.out.println(tokens[1]);
        System.out.println(tokens[2]);
        System.out.println(tokens[3]);

        // 예제 for문을 써서 위 결과와 동일하게 출력해주세요
        for (int i=0; i<tokens.length; i++) {
            System.out.println(tokens[i]);
        }
    }
}
