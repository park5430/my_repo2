package memory;
// 문자열에서 특정 글자를 인덱스하는 예시
public class char_ex {
    public static void main(String[] args) {
        String k_id = "8303221000000";
        char gender = k_id.charAt(6);
        switch (gender) {
            case '1':
            case '3':
            System.out.println("남자입니다");
            break;
            case '2':
            case '4':
            System.out.println("여자입니다");
            break;
        }
    }
}
