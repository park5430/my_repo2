package memory;
// 배열 변수를 생성해서 메모리의 차이가 어떤 영향을 미치는지 확인
public class memory_example {
    public static void main(String[] args) {
        int[] arr1;
        int[] arr2;
        int[] arr3;

        arr1 = new int[] {1,2,3}; // 배열 {1,2,3}을 생성하고 변수에 배정
        arr2 = new int[] {1,2,3};
        arr3 = arr2;
        // 같은 배열, 같은 값인데 하나는 다르다 하고 하나는 같다고 한다
        // 두 배열은 저장 항목은 같지만 서로다른 배열 객체로 생성되어서
        System.out.println(arr1 == arr2);
        System.out.println(arr2 == arr3);
    }
}
