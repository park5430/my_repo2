// 바이트 코드 파일이 위치할 폴더선언
package first_byte;

// public class App으로 App 클래스 선언 (클래스이름=파일이름)
// 클래스 이름은 숫자로 시작할 수 없고 공백없음
public class App {
    public static void main(String[] args) throws Exception {
        // 지금 괄호 안의 내용이 메소드의 본문입니다
        // System.out은 표준 출력 명령
        // println은 문자열 출력 후 자동 줄바꿈 추가
        System.out.println("Hello, World!");
    }
}
