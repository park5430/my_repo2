package var_type2;

public class force_type {
    public static void main(String[] args) {
int bbb = 100;
// 작은 허용범위타입 = (작은 허용범위타입) 큰 허용범위타입
byte ccc = (byte) bbb;
System.out.println(ccc);

// 실수에서 정수로 갈때 소수점 부분은 버려진다
double kkk = 3.17;
byte eee = (byte) kkk;
System.out.println(eee);
    }
}
