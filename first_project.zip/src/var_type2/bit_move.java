package var_type2;

// 비트이동 연산자: 2의 거듭제곱만큼 숫자크기를 변환
// 비트이동 연산자에서 1미만의 값이 나오면 
// 소수점이 버려지면서 0처리 되어요~

public class bit_move {
    public static void main(String[] args) {
float bitbit1 = 1 >> 3;
System.out.println(bitbit1);
int bitbit2 = 8 >> 3;
System.out.println(bitbit2);
    }
}
