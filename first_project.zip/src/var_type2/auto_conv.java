package var_type2;

public class auto_conv {
    public static void main(String[] args) {
        // 데이터 중 일부가 문자열이면 
        // 다른것도 문자열 처리해서 결과를 보여준다
String str = "3" + (1+3+1);
System.out.println(str);
    }
}
