package var_type2;

public class Char {
    public static void main(String[] args) {
String var1 = "자바는 \n빡빡한거 \t같아요";
System.out.println(var1);

    }
}
