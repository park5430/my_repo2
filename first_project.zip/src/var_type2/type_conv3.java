package var_type2;

public class type_conv3 {
    public static void main(String[] args) {
// 문자열을 기본 타입으로 변환하기

String str = "200";
int value = Integer.parseInt(str);
String str2 = "2000";
long value2 = Long.parseLong(str2);
System.out.println(value+55);
System.out.println(value2+555);
    }
}
