package var_type2;

public class overflow {
    public static void main(String[] args) {
byte x = 125;
for (int i=0; i<5; i++) {
    x++;
    System.out.println(x);
}

    }
}
