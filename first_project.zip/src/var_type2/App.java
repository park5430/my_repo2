package var_type2;

public class App {
    public static void main(String[] args) {
char x = 65;
int y = 5;
System.out.println("x:" + x + ", y:" + y);

    }
}
