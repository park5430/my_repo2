package var_type2;

public class float_prob1 {
    public static void main(String[] args) {
byte x = 1;
double y = 0.1;
int z = 7;
double result = x - y * z;
System.out.println(result);

    }
}
