// 커스텀훅 useDiary를 만듭니다. 직접 프로그래밍한 함수가 리액트 훅스
// 라는 것을 나타내기 위해 use앞에 꼭 붙이고요. 고유데이터를 구분하는 id를
// 인풋값으로 받습니다.

const useDiary = (id) => {
    return "";
}
export default useDiary