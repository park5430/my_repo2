
import './App.css';

function App() {
  return (
    <div className="App">

          Learn React

    </div>
  );
}

export default App;
