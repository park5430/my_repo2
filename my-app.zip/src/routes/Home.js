// React에서 제공하는 훅들과 컴포넌트를 불러옵니다.
import { useEffect, useState } from "react";

// 컴포넌트의 레이아웃을 정의한 컴포넌트를 불러옵니다.
import Layout from "../components/Layout";

// React Router의 Link 컴포넌트를 불러옵니다.
import { Link } from "react-router-dom";

// CSS 모듈을 불러와서 스타일을 적용합니다.
import styles from "./Home.module.css";

// API URL을 정의한 파일에서 apiUrl 상수를 가져옵니다.
import { apiUrl } from "../url";

// 홈 화면을 나타내는 함수형 컴포넌트를 정의합니다.
const Home = () => {
  // API에서 받아온 결과를 저장할 상태 변수를 선언합니다.
  const [results, setResults] = useState([]);

  // API에서 데이터를 가져오는 비동기 함수를 정의합니다.
  const getMovies = async () => {
    // Marvel API에 대한 요청을 보내고 결과를 JSON 형태로 파싱합니다.
    const json = await (await fetch(apiUrl.home)).json();
    
    // 결과 중에서 필요한 캐릭터 목록을 상태에 업데이트합니다.
    setResults(json.data.results);
  };

  // 컴포넌트가 마운트되었을 때 한 번만 API에서 데이터를 가져오기 위해 useEffect 훅을 사용합니다.
  useEffect(() => {
    getMovies();
  }, []);

  // 렌더링 결과를 반환합니다.
  return (
    // Layout 컴포넌트로 전체 레이아웃을 감싸고, 스타일을 적용한 컨테이너를 추가합니다.
    <Layout>
      <div className={styles.container}>
        {results.length > 0 &&
          // API에서 받아온 캐릭터 목록을 매핑하여 각각의 아이템을 렌더링합니다.
          results.map((result) => (
            // 각 캐릭터에 대한 정보를 담은 div 엘리먼트를 생성합니다.
            <div key={result.id} className={styles.item}>
              {/* Link 컴포넌트를 사용하여 캐릭터 세부 정보 페이지로 이동할 수 있는 링크를 생성합니다. */}
              <Link to={`/character/${result.id}`}>
                {/* 캐릭터의 이미지를 보여주는 img 엘리먼트를 추가합니다. */}
                <img
                  src={`${result.thumbnail.path}.${result.thumbnail.extension}`}
                  alt={result.id}
                />
                {/* 캐릭터의 이름을 보여주는 h1 엘리먼트를 추가합니다. */}
                <h1 className={styles.name}>
                  {/* 캐릭터의 이름이 10자를 초과하면 일부만 표시하고 "..."을 추가합니다. */}
                  {result.name.length > 10
                    ? result.name.slice(0, 10) + "..."
                    : result.name}
                </h1>
              </Link>
            </div>
          ))}
      </div>
    </Layout>
  );
};

// 컴포넌트를 내보냅니다.
export default Home;


// Layout 컴포넌트의 특징

// React 컴포넌트를 사용할 때, 기본적으로 컴포넌트는 <ComponentName /> 형식으로 사용됩니다. 
// 그러나 이 코드에서 <Layout> </Layout> 형태로 사용된 것은 
// React 컴포넌트의 자식 컴포넌트(children)를 포함하는 패턴 중 하나입니다.

// Layout 컴포넌트의 {children} 부분은 해당 레이아웃 안에 포함된 다른 컴포넌트들을 나타냅니다. 
// 이러한 방식으로 사용하면 Layout 컴포넌트로 
// 감싼 부분의 내용이 Layout 컴포넌트의 {children} 자리에 들어가게 됩니다.

// Layout 컴포넌트를 사용하는 예제
{/* <Layout backBtn={true}>
  <div>
    <h1>Hello, World!</h1>
    <p>This is the content of the page.</p>
  </div>
</Layout> */}

// 위의 예제에서 <div> 내부의 내용이 Layout 컴포넌트의 {children} 자리에 들어가게 되고, 
// 그 하위 컴포넌트들이 렌더링됩니다. 
// 이는 일종의 레이아웃 구조를 만들 때 유용한 방식 중 하나입니다. 