export const apiUrl = {
  home: "https://marvel-proxy.nomadcoders.workers.dev/v1/public/characters?limit=50&orderBy=modified&series=24229,1058,2023",
  detail: (id) =>
    `https://marvel-proxy.nomadcoders.workers.dev/v1/public/characters/${id}`,
};


// home 프로퍼티:

// 이 프로퍼티는 홈 화면에 표시될 캐릭터 목록을 가져오기 위한 API 엔드포인트입니다.
// URL은 다음과 같습니다: 
// "https://marvel-proxy.nomadcoders.workers.dev/v1/public/characters?limit=50&orderBy=modified&series=24229,1058,2023"
// limit=50: 반환되는 결과의 개수가 최대 50개로 제한됨을 나타냅니다.
// orderBy=modified: 결과를 수정된 날짜에 따라 정렬합니다.
// series=24229,1058,2023: 특정 시리즈에 속한 캐릭터만 필터링합니다. 
// 시리즈 ID는 24229, 1058, 2023입니다.


// detail 프로퍼티:

// 이 프로퍼티는 특정 캐릭터의 세부 정보를 가져오기 위한 API 엔드포인트를 생성하는 함수입니다.
// 함수는 id 매개변수를 받아 해당 캐릭터의 ID를 동적으로 처리하여 URL을 생성합니다.
// 예를 들어, detail(123)를 호출하면 다음과 같은 URL이 생성됩니다: 
// "https://marvel-proxy.nomadcoders.workers.dev/v1/public/characters/123"
// 이 코드는 Marvel API에 대한 요청을 보내고, 홈 화면 및 특정 캐릭터의 
// 세부 정보를 가져오기 위한 URL을 정의하는데 사용될 수 있습니다.