import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import Detail from "./routes/Detail";
import Home from "./routes/Home";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        {/* <Route path="/character/:id" element={<Detail />} /> */}
      </Routes>
    </Router>
  );
};

export default App;

// 이 코드는 React 어플리케이션에서 라우팅을 구현하기 위해 react-router-dom 라이브러리를 사용하는 예시입니다. 
// 간단한 어플리케이션 구조로 홈 화면과 특정 캐릭터의 세부 정보를 보여주는 페이지를 나타냅니다.

// BrowserRouter as Router:

// BrowserRouter는 React 어플리케이션에서 브라우저 기반의 라우팅을 지원하는 컴포넌트입니다.
// as Router는 BrowserRouter를 Router라는 별칭으로 사용하겠다는 의미입니다.
// <Routes>:

// Routes는 라우트들을 정의하는 컨테이너입니다.
// <Routes> 안에는 여러 개의 <Route> 컴포넌트가 포함될 수 있습니다.
// <Route>:

// <Route>는 경로와 해당 경로에 매칭될 때 렌더링할 컴포넌트를 지정합니다.
// <Route path="/">는 홈 화면을 나타내는 경로를 설정하고, 
// element={<Home />}는 해당 경로에 매칭되었을 때 렌더링할 컴포넌트로 Home 컴포넌트를 지정합니다.
// <Route path="/character/:id">는 특정 캐릭터의 세부 정보를 나타내는 경로를 설정하고, 
// element={<Detail />}는 해당 경로에 매칭되었을 때 렌더링할 컴포넌트로 Detail 컴포넌트를 지정합니다.
// <Router>:

// 최상위 컴포넌트인 Router는 라우트들을 감싸는 역할을 합니다. 
// 이를 통해 어플리케이션 전체에서 라우팅을 활성화합니다.
// 종합하면, 이 코드는 React 어플리케이션에서 사용되는 라우팅을 설정하고, 
// 홈 화면과 특정 캐릭터의 세부 정보를 보여주는 페이지에 대한 경로를 정의하는데 사용됩니다.