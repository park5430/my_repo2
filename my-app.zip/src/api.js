const useMutation = async (url) => {
  const json = await (await fetch(url)).json();
  const results = await json.data.results;
  return results;
};

export default useMutation;

// 이 코드의 목적은 주어진 URL에서 비동기적으로 데이터를 가져와서 
// 그 중에서 data.results를 반환하는 것입니다. 
// 주로 API 호출과 같이 외부에서 데이터를 가져오는 상황에서 사용될 수 있습니다. 
// 코드에서는 await와 async를 사용하여 비동기 처리를 간편하게 수행하고 있습니다.

// https://marvel-proxy.nomadcoders.workers.dev/v1/public/characters/1009572
// 데이터를 예를 든다면 data.results를 가져온다에 대해 이해하시기 편하실 겁니다.