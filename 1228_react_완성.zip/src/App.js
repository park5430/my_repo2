// CRUD 기능의 대표적인 구현 방법은 REACT HOOKS 중에 useState입니다
import "./App.css";
import Header from "./component/Header";
import TodoEditor from "./component/TodoEditor";
import TodoList from "./component/TodoList";
import { useState, useRef } from "react";

// 가짜 json형식의 데이터 객체를 형성하여 crud로직을 만들고
// 실제데이터를 갈아끼우는 형태로 개발하시면 됩니다

const mockTodo = [
  {
    id: 0,
    inDone: false,
    content: "react 공부",
    createdDate: new Date().getTime(),
  },
  {
    id: 1,
    inDone: false,
    content: "개발자 되기",
    createdDate: new Date().getTime(),
  },
  {
    id: 2,
    inDone: false,
    content: "자료 다운로드",
    createdDate: new Date().getTime(),
  },
];

function App() {
  // useRef의 초기값을 3으로 설정한 이유는
  // 우리가 생성한 가짜데이터 id가 2로 끝나서입니다
  const idRef = useRef(3);
  const [todo, setTodo] = useState(mockTodo);

  const onCreate = (content) => {
    //  todoEditor 컴포넌트에서 <추가> 버튼을 누르면 호출될 함수 onCreate를 만들었습니다
    // 함수는 사용자가 작성한 데이터를 받아 변수 content에 저장합니다
    // 받아서 저장한 데이터로 새 할일 객체를 만들어 newItem에 저장합니다
    // 아래처럼 id를 0으로 설정하면 기존 데이터 id와 중복되는 문제가 있습니다
    const newItem = {
      id: idRef.current,
      content,
      isDone: false,
      createdDate: new Date().getTime(),
    };
    // 배열의 스프레드 연산자를 이용해 newItem을 포함한 새 배열을 만들어서
    // state변수를 업데이트 합니다 새롭게 추가되는 아이템은 항상 배열의 0번 요소입니다

    setTodo([newItem, ...todo]);
    idRef.current += 1;
  };
  // 함수 onUpdate는 TodoItem에 이벤트가 발생했을때 호출됩니다
  // 어떤 TodoItem에 이벤트가 발생했는지 알아야 하므로 아이템 데이터의
  // id를 저장합니다.
  // todo값을 업데이트 하기 위해 SetTodo를 호출합니다.
  // map 메서드를 이용해서 it.id === targetId 조건을 만족하면
  // 새 배열 데이터를 만들어서 인수(인풋)값으로 전달합니다
  const onUpdate = (targetId) => {
    setTodo(
      todo.map((it) => 
      it.id === targetId ? {...it, isDone: !it.isDone} : it
      ) 
    );
  };
  const onDelete = (targetId) => {
    setTodo(todo.filter((it) => it.id !== targetId))
  };
  return (
    <div className="App">
      <Header />
      <TodoEditor onCreate={onCreate} />
      {/* 배열 todo를 TodoList 컴포넌트에 
      props로 전달합니다 */}
      <TodoList todo={todo} onUpdate={onUpdate} onDelete={onDelete}/>
    </div>
  );
}

export default App;
